package com.rental.carrental.exception;

public class RentalDetailsNullExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public RentalDetailsNullExcep() {
		this.text = "Car Not Found";
		
	}
	public RentalDetailsNullExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}
