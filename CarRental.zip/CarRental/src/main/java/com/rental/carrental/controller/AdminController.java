package com.rental.carrental.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.rental.carrental.model.Car;
import com.rental.carrental.restcontroller.CarRestController;
import com.rental.carrental.restcontroller.CustomerRestController;
import com.rental.carrental.restcontroller.RentalDetailsRestController;





@Controller
@RequestMapping("/admin")
public class AdminController {
	
	private static final Log log = LogFactory.getLog(AdminController.class);

	@Autowired
	CarRestController carRest;
	
	@Autowired
	CustomerRestController customerRest;

	@Autowired
	RentalDetailsRestController rentRest;

	@GetMapping("/carForm")
	public ModelAndView getCarFormPage(ModelAndView mav, @ModelAttribute("car") Car car) {
		mav.addObject("car", car);
		mav.setViewName("CarFormPage");
		return mav;
	}
	
	@RequestMapping("/add-car")
	public ModelAndView postNewCar(ModelAndView mav, @ModelAttribute("car") Car car) {
		ResponseEntity<Object> responseEntity = carRest.postCar(car);

		if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
			mav.addObject("msg", "car created");
			mav.setViewName("HomePage");

		} else if (responseEntity.getStatusCode() == HttpStatus.ALREADY_REPORTED
				|| responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
			mav.setViewName("CarFormPage");
			mav.addObject("car", car);
			mav.addObject("msg", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		} else {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", "Unknown Problem");
		}
		
		return mav;
	}
	
	@GetMapping("/all-customer")
	public ModelAndView getAllCustomer(ModelAndView mav) {
		ResponseEntity<Object> responseEntity = customerRest.getAllCustomer();

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			mav.setViewName("AllCustomerPage");
			List<?> customerList = null;
			if ((customerList = ((List<?>) responseEntity.getBody())) != null) {
				if (customerList.isEmpty()) {
					mav.addObject("msg", "No User Found");
				} else {
					mav.addObject("customerList", customerList);
				}
			}
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		}

		return mav;
	}

	@GetMapping("/all-car")
	public ModelAndView getAllCar(ModelAndView mav) {
		ResponseEntity<Object> responseEntity = carRest.getAllCar();

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			mav.setViewName("AllCarPage");
			List<?> carList = null;
			if ((carList = ((List<?>) responseEntity.getBody())) != null) {
				if (carList.isEmpty()) {
					mav.addObject("msg", "No Car Found");
				} else {
					mav.addObject("carList", carList);
				}
			}
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		}

		return mav;
	}

	@GetMapping("/all-rentaldetail")
	public ModelAndView getAllRentalDetail(ModelAndView mav) {
		ResponseEntity<Object> responseEntity = rentRest.getAllRentalDetail();

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			mav.setViewName("AllRentalDetailPage");
			List<?> rendalDetailList = null;
			if ((rendalDetailList = ((List<?>) responseEntity.getBody())) != null) {
				if (rendalDetailList.isEmpty()) {
					mav.addObject("msg", "No Rental Detail Found");
				} else {
					mav.addObject("rendalDetailList", rendalDetailList);
				}
			}
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		}

		return mav;
	}
	
	

	@RequestMapping("/car-delete/{carNo}")
	@PreAuthorize("hasRole('ADMIN')")
	public ModelAndView deletCar(ModelAndView mav, @PathVariable(name = "carNo") String carNo) {
		ResponseEntity<Object> responseEntity = carRest.deleteCarById(carNo);

		if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {

			mav.addObject("msgDelete", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {

			mav.addObject("msg", responseEntity.getBody());

		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.addObject("msg", "This car can't be delete");
		}
		this.getAllCar(mav);
		return mav;
	}

	@RequestMapping("/customer-delete/{customerId}")
	@PreAuthorize("hasRole('ADMIN')")
	public ModelAndView deleteCustomer(ModelAndView mav, @PathVariable(name = "customerId") Integer customerId) {
		ResponseEntity<Object> responseEntity = customerRest.deleteCustomerById(customerId);

		if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {

			mav.addObject("msgDelete", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {

			mav.addObject("msg", responseEntity.getBody());

		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", "This customer can't be delete");
		}
		this.getAllCustomer(mav);
		return mav;
	}

	@RequestMapping("/rentaldetail-delete/{rentalId}")
	@PreAuthorize("hasRole('ADMIN')")
	public ModelAndView deleteRentalDetail(ModelAndView mav, @PathVariable(name = "rentalId") Integer rentalId) {
		ResponseEntity<Object> responseEntity = rentRest.deleteRentalDetailById(rentalId);

		if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {

			mav.addObject("msgDelete", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {

			mav.addObject("msg", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.addObject("msg", "This Rental detail can't be delete");

		}
		this.getAllRentalDetail(mav);
		return mav;
	}
}
