package com.rental.carrental.exception;

public class UserNotFoundExcep extends RuntimeException{

	private static final long serialVersionUID = 1L;
	private final String text;
	public UserNotFoundExcep() {
		this.text = "User Not Found";
		
	}
	public UserNotFoundExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return text;
	}
	
	
	
}
