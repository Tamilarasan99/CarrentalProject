package com.rental.carrental.service;

import java.util.Date;
import java.util.List;

import com.rental.carrental.exception.CarNotFoundExcep;
import com.rental.carrental.exception.CarNullExcep;
import com.rental.carrental.model.Car;

public interface CarService {

public Car findById(String id) throws CarNotFoundExcep;
	
	public List<Car> findAll();
	
	public Car save(Car car) throws CarNullExcep;
	
	public void deleteById(String id) throws CarNotFoundExcep;
	
	public boolean existsById(String id) throws CarNotFoundExcep;

	public List<Car> findAvailableCarsBwtweenDates(Date startDate, Date endDate) throws NullPointerException;

}
