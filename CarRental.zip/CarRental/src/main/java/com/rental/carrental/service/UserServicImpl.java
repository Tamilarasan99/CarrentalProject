package com.rental.carrental.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;


import com.rental.carrental.entity.UserEntity;

import com.rental.carrental.exception.UserNotFoundExcep;
import com.rental.carrental.exception.UserNullExcep;

import com.rental.carrental.model.User;

import com.rental.carrental.repository.UserRepo;

@Service
public class UserServicImpl implements UserService{

	@Autowired
	private WebApplicationContext con;
	
	@Autowired
	private UserRepo userRepo;
	
	private static final String ID_NOT_NULL="User id cannot be null";
	private static final String VALUE_EMPTY="User not found for this ID";
	private static final String USER_NOT_NULL="User cannot be null";
	
	private User getUserBean() {
		return con.getBean(User.class);
	}
	
	private UserEntity getUserEntityyBean() {
		return con.getBean(UserEntity.class);
	}

	
	@Override
	public User findById(Integer id) throws UserNotFoundExcep {
		if(id == null ) {
			throw new UserNotFoundExcep(ID_NOT_NULL);
		}
		Optional<UserEntity> userEntityValue = userRepo.findById(id);
		if(userEntityValue.isEmpty()) {
			throw new UserNotFoundExcep(VALUE_EMPTY);
		}
		
		User user = this.getUserBean();
		BeanUtils.copyProperties(userEntityValue.get(), user);
		
		
		return user;
	}

	@Override
	public List<User> findAll() {
          
		List<UserEntity> userEntityList = userRepo.findAll();
		
		List<User> userList = new ArrayList<>();
		for(UserEntity userEntity : userEntityList) {
			
			User user = this.getUserBean();
			BeanUtils.copyProperties(userEntity, user);
			userList.add(user);
		}
		return userList;
	}

	@Override
	public User save(User user) throws UserNullExcep {
		
		if(user == null) {
			throw new UserNullExcep(USER_NOT_NULL);
		}
		
	     UserEntity userEntity = this.getUserEntityyBean();
		BeanUtils.copyProperties(user, userEntity);
		userEntity = userRepo.save(userEntity);
		
		BeanUtils.copyProperties(userEntity, user);
		
		return user;
	}

	@Override
	public void deleteById(Integer id) throws UserNotFoundExcep {
		
		if( id == null ) {
			throw new UserNotFoundExcep(USER_NOT_NULL);
		}
		
		if( !this.existsById(id) ) {
			throw new UserNotFoundExcep(VALUE_EMPTY);
		}
		userRepo.deleteById(id);	
		
	}

	@Override
	public boolean existsById(Integer id) throws UserNotFoundExcep {
		
		if(id == null) {
			throw new UserNotFoundExcep(USER_NOT_NULL);
		}
		return userRepo.existsById(id);
	}

	@Override
	public long count() {
		return userRepo.count();
	}

}
