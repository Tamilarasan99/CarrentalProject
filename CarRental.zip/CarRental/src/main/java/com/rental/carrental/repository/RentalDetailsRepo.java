package com.rental.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rental.carrental.entity.RentalDetailsEntity;

public interface RentalDetailsRepo extends JpaRepository<RentalDetailsEntity, Integer>{

}
