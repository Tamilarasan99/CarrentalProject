package com.rental.carrental.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;


import com.rental.carrental.entity.CustomerEntity;
import com.rental.carrental.exception.CarNotFoundExcep;

import com.rental.carrental.exception.CustomerNotFoundExcep;
import com.rental.carrental.exception.CustomerNullExcep;

import com.rental.carrental.model.Customer;

import com.rental.carrental.repository.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private WebApplicationContext con;
	
	@Autowired
	private CustomerRepo cusRepo;
	
	private static final String ID_NOT_NULL="Customer id cannot be null";
	private static final String VALUE_EMPTY="Customer not found for this ID";
	private static final String CUSTOMER_NOT_NULL="Customer cannot be null";
	
	private Customer getCustomerBean() {
		return con.getBean(Customer.class);
	}
	
	private CustomerEntity getCustomerEntityyBean() {
		return con.getBean(CustomerEntity.class);
	}

	@Override
	public Customer findById(Integer id) throws CustomerNotFoundExcep {
	
		if(id == null ) {
			throw new CustomerNotFoundExcep(ID_NOT_NULL);
		}
		Optional<CustomerEntity> cusEntityValue = cusRepo.findById(id);
		if(cusEntityValue.isEmpty()) {
			throw new CarNotFoundExcep(VALUE_EMPTY);
		}
		
		Customer customer = this.getCustomerBean();
		BeanUtils.copyProperties(cusEntityValue.get(), customer);
		
		
		return customer;
	
	}

	@Override
	public List<Customer> findAll() {
            List<CustomerEntity> cusEntityList = cusRepo.findAll();
		
		List<Customer> customerList = new ArrayList<>();
		for(CustomerEntity customerEntity : cusEntityList) {
			
			Customer customer = this.getCustomerBean();
			BeanUtils.copyProperties(customerEntity, customer);
			customerList.add(customer);
		}
		return customerList;
	}

	@Override
	public Customer save(Customer customer) throws CustomerNullExcep {
		if(customer == null) {
			throw new CustomerNullExcep(CUSTOMER_NOT_NULL);
		}
		
		CustomerEntity cusEntity = this.getCustomerEntityyBean();
		BeanUtils.copyProperties(customer, cusEntity);
		cusEntity = cusRepo.save(cusEntity);
		
		BeanUtils.copyProperties(cusEntity, customer);
		
		return customer;
	}

	@Override
	public void deleteById(Integer id) throws CustomerNotFoundExcep {
		if( id == null ) {
			throw new CustomerNotFoundExcep(CUSTOMER_NOT_NULL);
		}
		
		if( !this.existsById(id) ) {
			throw new CustomerNotFoundExcep(VALUE_EMPTY);
		}
		cusRepo.deleteById(id);	
	}

	@Override
	public boolean existsById(Integer id) throws CustomerNotFoundExcep {
		if(id == null) {
			throw new CustomerNotFoundExcep(CUSTOMER_NOT_NULL);
		}
		return cusRepo.existsById(id);
	}
	
}
