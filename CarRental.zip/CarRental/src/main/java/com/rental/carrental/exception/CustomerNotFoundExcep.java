package com.rental.carrental.exception;

public class CustomerNotFoundExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public CustomerNotFoundExcep() {
		this.text = "Customer Not Found";
		
	}
	public CustomerNotFoundExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}
