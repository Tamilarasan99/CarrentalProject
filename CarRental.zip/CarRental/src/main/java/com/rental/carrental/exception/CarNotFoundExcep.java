package com.rental.carrental.exception;

public class CarNotFoundExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public CarNotFoundExcep() {
		this.text = "Car Not Found";
		
	}
	public CarNotFoundExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}
