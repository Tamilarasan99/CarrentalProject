package com.rental.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rental.carrental.entity.CustomerEntity;

public interface CustomerRepo extends JpaRepository<CustomerEntity, Integer>{

}
