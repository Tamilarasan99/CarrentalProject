package com.rental.carrental.model;

import java.util.Arrays;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
@Scope("prototype")
public class Car {

	private String carModel;
	private String carNo;
	private int seatcount;
	private double rentPerday;
	private byte[] carImage;
	public Car() {
		super();
	}
	public Car(String carModel, String carNo, int seatcount, double rentPerday, byte[] carImage) {
		super();
		this.carModel = carModel;
		this.carNo = carNo;
		this.seatcount = seatcount;
		this.rentPerday = rentPerday;
		this.carImage = carImage;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getCarNo() {
		return carNo;
	}
	public void setCarNo(String carNo) {
		this.carNo = carNo;
	}
	public int getSeatcount() {
		return seatcount;
	}
	public void setSeatcount(int seatcount) {
		this.seatcount = seatcount;
	}
	public double getRentPerday() {
		return rentPerday;
	}
	public void setRentPerday(double rentPerday) {
		this.rentPerday = rentPerday;
	}
	public byte[] getCarImage() {
		return carImage;
	}
	public void setCarImage(byte[] carImage) {
		this.carImage = carImage;
	}
	@Override
	public String toString() {
		return "Car [carModel=" + carModel + ", carNo=" + carNo + ", seatcount=" + seatcount + ", rentPerday="
				+ rentPerday + ", carImage=" + Arrays.toString(carImage) + "]";
	}
	
	
}
