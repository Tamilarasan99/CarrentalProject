package com.rental.carrental.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rental.carrental.restcontroller.CarRestController;



@Controller
public class HomeController {

	@Autowired
	private CarRestController carRest;

	@GetMapping({ "/", "/home" })
	public String getHomePage() {
		return "HomePage";
	}

	@GetMapping("/rental-cars")
	public String getRentalDatePage() {
		return "RentalDatePage";
	}

	@PostMapping("/cars-by-date")
	public String postRentalDate(
			@RequestParam(name = "StartDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam(name = "EndDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
		return "redirect:/get-cars-by-date/" + startDate + "/" + endDate;
	}

	@GetMapping("/get-cars-by-date/{startDate}/{endDate}")
	public ModelAndView getRentalCarsByDate(ModelAndView mav,
			@PathVariable(name = "startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@PathVariable(name = "endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {

		Map<String, Object> model = mav.getModel();
		if (model.containsKey("msg")) {
			mav.addObject("msg", model.get("msg"));
		}

		ResponseEntity<Object> responseEntity = carRest.carAvailableByDates(startDate, endDate);

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			mav.setViewName("RentalCarViewPage");
			List<?> carList = null;
			if ((carList = ((List<?>) responseEntity.getBody())) != null) {
				if (carList.isEmpty()) {
					mav.addObject("msg", "No Car Found");
				} else {
					mav.addObject("carList", carList);
				}
			}
			mav.addObject("startDate", startDate);
			mav.addObject("endDate", endDate);

		} else if (responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
			mav.setViewName("RentalDatePage");
			mav.addObject("msg", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		} else {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", "Unknown Problem");
		}

		return mav;
	}
	
	@GetMapping("/error")
	public ModelAndView errorOccur(ModelAndView mav ,@RequestParam("type") String type, @RequestParam("status") String status) {
		mav.addObject("msg", "Type = " + type + ", Status = " + status);
		mav.setViewName("ErrorPage");
		return mav;
	}
}
