package com.rental.carrental.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.rental.carrental.enumeration.Role;
import com.rental.carrental.model.Address;
import com.rental.carrental.model.Customer;
import com.rental.carrental.restcontroller.CustomerRestController;
import com.rental.carrental.restcontroller.RentalDetailsRestController;
import com.rental.carrental.restcontroller.UserRestController;







@Controller
@RequestMapping("/customer")
public class CustomerController {

	private static final Log log = LogFactory.getLog(CustomerController.class);
	
	@Autowired
	CustomerRestController customerRest;
	
	@Autowired
	WebApplicationContext con;
	
	@Autowired
	UserRestController userRest;
	
	@Autowired
	RentalDetailsRestController rentRest;


	@GetMapping("/customer-form")
	public ModelAndView getCustomerFormPage(ModelAndView mav, @ModelAttribute("customer") Customer customer) {
		
		ResponseEntity<Object> responseEntity = userRest.userCount();	
		Object body = responseEntity.getBody();
		long value = -1;
		if (body instanceof Long) {
		    value = (long) body;
		}	
		
		if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
			return mav;
		} else if( value == 0 ) {
			customer.setRole(Role.ADMIN);
			mav.addObject("msg", "Admin creation");
		}  else {
			customer.setRole(Role.USER);
		}
		
		mav.addObject("customer", customer);
		mav.setViewName("CustomerFormPage");
		return mav;
	}

	@RequestMapping("/add-customer")
	public ModelAndView postNewCustomer(ModelAndView mav, @ModelAttribute("customer") Customer customer) {
		ResponseEntity<Object> responseEntity = customerRest.postCustomer(customer);
		Customer customerReturn = (Customer) responseEntity.getBody();

		if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
			if (customerReturn != null) {
				mav.addObject("msg", "customer created and id = " + customerReturn.getUserId());
			}
			mav.setViewName("HomePage");

		} else if (responseEntity.getStatusCode() == HttpStatus.ALREADY_REPORTED
				|| responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
			mav.setViewName("CarFormPage");
			mav.addObject("customer", customer);
			mav.addObject("msg", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", responseEntity.getBody());
		} else {
			mav.setViewName("ErrorPage");
			mav.addObject("msg", "Unknown Problem");
		}

		return mav;
	}
	
	
}
