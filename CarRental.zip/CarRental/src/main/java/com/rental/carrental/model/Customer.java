package com.rental.carrental.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.rental.carrental.enumeration.Role;

@Component
@Scope("prototype")
public class Customer extends User{

	private String name;
	private int age;
	private String phoneNo;
	private boolean validLicense;
	
	private Address address;

	public Customer() {
		super();
	}

	public Customer(String name, int age, String phoneNo, boolean validLicense, Address address,String userPassword, Role role) {
		super(userPassword,role);
		this.name = name;
		this.age = age;
		this.phoneNo = phoneNo;
		this.validLicense = validLicense;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public boolean isValidLicense() {
		return validLicense;
	}

	public void setVaildLicense(boolean validLicense) {
		this.validLicense = validLicense;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", age=" + age + ", phoneNo=" + phoneNo + ", vaildLicense=" + validLicense
				+ ", address=" + address + "]";
	}

	
	
	
}
