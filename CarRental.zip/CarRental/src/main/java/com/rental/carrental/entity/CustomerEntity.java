package com.rental.carrental.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Component
@Scope("prototype")
@Entity

public class CustomerEntity extends UserEntity {

	private String name;
	private int age;
	private String phoneNo;
	private boolean validLicense;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "address_id")
	private AddressEntity address;
	
	public CustomerEntity() {
		super();
	}

	public CustomerEntity(String name, int age, String phoneNo, boolean validLicense, AddressEntity address) {
		super();
		this.name = name;
		this.age = age;
		this.phoneNo = phoneNo;
		this.validLicense = validLicense;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public boolean isVaildLicense() {
		return validLicense;
	}

	public void setVaildLicense(boolean validLicense) {
		this.validLicense = validLicense;
	}

	public AddressEntity getAddress() {
		return address;
	}

	public void setAddress(AddressEntity address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "CustomerEntity [name=" + name + ", age=" + age + ", phoneNo=" + phoneNo + ", vaildLicense="
				+ validLicense + ", address=" + address + "]";
	}

	
	
}
