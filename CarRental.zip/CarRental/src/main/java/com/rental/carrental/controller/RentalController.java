package com.rental.carrental.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rental.carrental.enumeration.Status;
import com.rental.carrental.model.Car;
import com.rental.carrental.model.Customer;
import com.rental.carrental.model.RentalDetails;
import com.rental.carrental.restcontroller.CarRestController;
import com.rental.carrental.restcontroller.CustomerRestController;
import com.rental.carrental.restcontroller.RentalDetailsRestController;


@Controller
@RequestMapping("/rent")
public class RentalController {
	
	private static final String ERROR_PAGE = "ErrorPage" ;

	@Autowired
	CustomerRestController customerRest;

	@Autowired
	CarRestController carRest;

	@Autowired
	RentalDetailsRestController rentalRest;

	private UserDetails getUserDetails() {
		SecurityContext con = SecurityContextHolder.getContext();
		Authentication authentication = con.getAuthentication();
		if (!(authentication instanceof UsernamePasswordAuthenticationToken)) {
			return null;
		}
		return (UserDetails) authentication.getPrincipal();
	}

	private Customer getCustomerById(ModelAndView mav, Integer customerId) {
		ResponseEntity<Object> customerResponseEntity = customerRest.getCustomerById(customerId);

		if (customerResponseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {
			mav.setViewName("LoginPage");
			mav.addObject("msg", customerResponseEntity.getBody());
			return null;

		} else if (customerResponseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName(ERROR_PAGE);
			mav.addObject("msg", customerResponseEntity.getBody());
			return null;

		}

		return (Customer) customerResponseEntity.getBody();
	}

	private Car getCarById(ModelAndView mav, String carNo, Date startDate, Date endDate) {
		ResponseEntity<Object> carResponseEntity = carRest.getCarById(carNo);

		if (carResponseEntity.getStatusCode() == HttpStatus.NOT_FOUND) {
			mav.setViewName("redirect:/get-cars-by-date/" + startDate + "/" + endDate);
			mav.addObject("msg", carResponseEntity.getBody());
			return null;

		} else if (carResponseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName(ERROR_PAGE);
			mav.addObject("msg", carResponseEntity.getBody());
			return null;

		}

		return (Car) carResponseEntity.getBody();
	}

	@GetMapping("/new-rent/display/{carId}/{startDate}/{endDate}")
	public ModelAndView getNewRentDisplayPage(ModelAndView mav,
			@ModelAttribute("rentalDetail") RentalDetails rentalDetail, @RequestParam(name = "carId") String carId,
			@RequestParam(name = "startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam(name = "endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
		UserDetails userDetail = this.getUserDetails();
		if (userDetail == null) {
			mav.setViewName("LoginPage");
			mav.addObject("msg", "Login First");
			return mav;

		}

		Integer customerId = Integer.parseInt(userDetail.getUsername());
		Customer customer = this.getCustomerById(mav, customerId);
		if (customer == null) {
			return mav;
		}

		Car car = this.getCarById(mav, carId, startDate, endDate);
		if (car == null) {
			return mav;
		}

		rentalDetail.setRentalCustomer(customer);
		rentalDetail.setRentalCar(car);
		rentalDetail.setStartDate(startDate);
		rentalDetail.setEndDate(endDate);
		rentalDetail.setStatus(Status.OPEN);

		mav.addObject("rentalDetail", rentalDetail);
		mav.setViewName("NewRentalPage");

		return mav;
	}

	@RequestMapping("/confirm-rent")
	public ModelAndView postRentalDetail(ModelAndView mav, @ModelAttribute("rentalDetail") RentalDetails rentalDetail) {
		ResponseEntity<Object> responseEntity = rentalRest.postRentalDetail(rentalDetail);

		if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
			mav.addObject("msg", "car booked");
			mav.setViewName("HomePage");

		} else if (responseEntity.getStatusCode() == HttpStatus.ALREADY_REPORTED
				|| responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
			mav.setViewName("HomePage");
			mav.addObject("msg", responseEntity.getBody());
		} else if (responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			mav.setViewName(ERROR_PAGE);
			mav.addObject("msg", responseEntity.getBody());
		} else {
			mav.setViewName(ERROR_PAGE);
			mav.addObject("msg", "Unknown Problem");
		}
		
		return mav;
	}

}

