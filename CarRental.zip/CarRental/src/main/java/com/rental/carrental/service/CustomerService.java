package com.rental.carrental.service;

import java.util.List;

import com.rental.carrental.exception.CustomerNotFoundExcep;
import com.rental.carrental.exception.CustomerNullExcep;
import com.rental.carrental.model.Customer;

public interface CustomerService {

public Customer findById(Integer id) throws CustomerNotFoundExcep;
	
	public List<Customer> findAll();
	
	public Customer save(Customer customer) throws CustomerNullExcep;
	
	public void deleteById(Integer id) throws CustomerNotFoundExcep;
	
	public boolean existsById(Integer id) throws CustomerNotFoundExcep;
}
