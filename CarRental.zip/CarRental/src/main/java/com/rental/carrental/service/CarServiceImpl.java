package com.rental.carrental.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import com.rental.carrental.entity.CarEntity;
import com.rental.carrental.exception.CarNotFoundExcep;
import com.rental.carrental.exception.CarNullExcep;
import com.rental.carrental.model.Car;
import com.rental.carrental.repository.CarRepo;


@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private WebApplicationContext con;
	
	@Autowired
	private CarRepo carrepo;
	
	private static final String ID_NOT_NULL="Car id cannot be null";
	private static final String VALUE_EMPTY="Car not found for this ID";
	private static final String CAR_NOT_NULL="Car cannot be null";
	private static final String CAR_NULLPTR="Car null";
	
	private Car getCarBean() {
		return con.getBean(Car.class);
	}
	
	private CarEntity getCarEntityBean() {
		return con.getBean(CarEntity.class);
	}
	@Override
	public Car findById(String id) throws CarNotFoundExcep {
		if(id == null ) {
			throw new CarNotFoundExcep(ID_NOT_NULL);
		}
		Optional<CarEntity> carEntityValue = carrepo.findById(id);
		if(carEntityValue.isEmpty()) {
			throw new CarNotFoundExcep(VALUE_EMPTY);
		}
		
		Car car = this.getCarBean();
		BeanUtils.copyProperties(carEntityValue.get(), car);
		
		
		return car;
	}

	@Override
	public List<Car> findAll() {
		List<CarEntity> carEntityList = carrepo.findAll();
		
		List<Car> carList = new ArrayList<>();
		for(CarEntity carEntity : carEntityList) {
			
			Car car = this.getCarBean();
			BeanUtils.copyProperties(carEntity, car);
			carList.add(car);
		}
		return carList;
	}

	@Override
	public Car save(Car car) throws CarNullExcep {
		if(car == null) {
			throw new CarNullExcep(CAR_NOT_NULL);
		}
		
		CarEntity carEntity = this.getCarEntityBean();
		BeanUtils.copyProperties(car, carEntity);
		
		carEntity = carrepo.save(carEntity);
		BeanUtils.copyProperties(carEntity, car);
		
		return car;
	}
	

	@Override
	public void deleteById(String id) throws CarNotFoundExcep {
		if( id == null ) {
			throw new CarNotFoundExcep(CAR_NOT_NULL);
		}
		
		if( !this.existsById(id) ) {
			throw new CarNotFoundExcep(VALUE_EMPTY);
		}
		carrepo.deleteById(id);	
		
	}

	@Override
	public boolean existsById(String id) throws CarNotFoundExcep {
		if(id == null) {
			throw new CarNotFoundExcep(CAR_NOT_NULL);
		}
		return carrepo.existsById(id);
	}

	@Override
	public List<Car> findAvailableCarsBwtweenDates(Date startDate, Date endDate) throws NullPointerException {
		
		if(startDate == null || endDate == null) {
			throw new NullPointerException(CAR_NULLPTR);
		}
		
      List<CarEntity> carEntityList = carrepo.findAvailableCarsBwtweenDates(startDate, endDate);
		
		List<Car> carList = new ArrayList<>();
		for(CarEntity carEntity : carEntityList) {
			
			Car car = this.getCarBean();
			BeanUtils.copyProperties(carEntity, car);
			carList.add(car);
		}
		return carList;
	}

}
