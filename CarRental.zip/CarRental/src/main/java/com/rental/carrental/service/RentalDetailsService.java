package com.rental.carrental.service;

import java.util.List;

import com.rental.carrental.exception.RentalDetailsNotFoundExcep;
import com.rental.carrental.exception.RentalDetailsNullExcep;
import com.rental.carrental.model.RentalDetails;

public interface RentalDetailsService {

 public RentalDetails findById(Integer id) throws RentalDetailsNotFoundExcep;
	
	public List<RentalDetails> findAll();
	
	public RentalDetails save(RentalDetails rentaldetails) throws RentalDetailsNullExcep;
	
	public void deleteById(Integer id) throws RentalDetailsNotFoundExcep;
	
	public boolean existsById(Integer id) throws RentalDetailsNotFoundExcep;
}
