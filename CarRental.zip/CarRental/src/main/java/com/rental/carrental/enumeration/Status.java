package com.rental.carrental.enumeration;

public enum Status {

	OPEN,CLOSE
}
