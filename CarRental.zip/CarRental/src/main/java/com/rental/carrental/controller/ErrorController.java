package com.rental.carrental.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
@RequestMapping("/error")
public class ErrorController {

	@ExceptionHandler(value = { Exception.class })
	public ModelAndView handleForbiddenException(Exception e) {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("msg", e.getMessage());
		modelAndView.setViewName("ErrorPage");
		return modelAndView;
	}
}
