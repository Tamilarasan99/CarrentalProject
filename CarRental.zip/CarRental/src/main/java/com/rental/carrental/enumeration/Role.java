package com.rental.carrental.enumeration;

public enum Role {

	ADMIN,USER
}
