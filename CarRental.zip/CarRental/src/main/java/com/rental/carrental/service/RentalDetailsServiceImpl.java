package com.rental.carrental.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;


import com.rental.carrental.entity.RentalDetailsEntity;

import com.rental.carrental.exception.RentalDetailsNotFoundExcep;

import com.rental.carrental.exception.RentalDetailsNullExcep;
import com.rental.carrental.model.RentalDetails;

import com.rental.carrental.repository.RentalDetailsRepo;

@Service
public class RentalDetailsServiceImpl implements RentalDetailsService{

	@Autowired
	private WebApplicationContext con;
	
	@Autowired
	private RentalDetailsRepo rentalRepo;
	
	private static final String ID_NOT_NULL="RentalDetails id cannot be null";
	private static final String VALUE_EMPTY="RentalDetails not found for this ID";
	private static final String RENTALDETAILS_NOT_NULL="RentalDetails cannot be null";
	
	private RentalDetails getRentalDetailsBean() {
		return con.getBean(RentalDetails.class);
	}
	
	private RentalDetailsEntity getRentalDetailsEntityyBean() {
		return con.getBean(RentalDetailsEntity.class);
	}
	
	
	@Override
	public RentalDetails findById(Integer id) throws RentalDetailsNotFoundExcep {
		if(id == null ) {
			throw new RentalDetailsNotFoundExcep(ID_NOT_NULL);
		}
		Optional<RentalDetailsEntity> rentalEntityValue = rentalRepo.findById(id);
		if(rentalEntityValue.isEmpty()) {
			throw new RentalDetailsNotFoundExcep(VALUE_EMPTY);
		}
		
		RentalDetails rentaldetails = this.getRentalDetailsBean();
		BeanUtils.copyProperties(rentalEntityValue.get(), rentaldetails);
		
		
		return rentaldetails;
	}

	@Override
	public List<RentalDetails> findAll() {
              List<RentalDetailsEntity> rentalEntityList = rentalRepo.findAll();
		
		List<RentalDetails> rentalDetailsList = new ArrayList<>();
		for(RentalDetailsEntity rentalDetailsEntity : rentalEntityList) {
			
			RentalDetails rentalDetails = this.getRentalDetailsBean();
			BeanUtils.copyProperties(rentalDetailsEntity, rentalDetails);
			rentalDetailsList.add(rentalDetails);
		}
		return rentalDetailsList;
	}

	@Override
	public RentalDetails save(RentalDetails rentaldetails) throws RentalDetailsNullExcep {
		if(rentaldetails == null) {
			throw new RentalDetailsNullExcep(RENTALDETAILS_NOT_NULL);
		}
		
		RentalDetailsEntity rentalDetailsEntity = this.getRentalDetailsEntityyBean();
		BeanUtils.copyProperties(rentaldetails, rentalDetailsEntity);
		rentalDetailsEntity = rentalRepo.save(rentalDetailsEntity);
		
		BeanUtils.copyProperties(rentalDetailsEntity, rentaldetails);
		
		return rentaldetails;
	}

	@Override
	public void deleteById(Integer id) throws RentalDetailsNotFoundExcep {
		if( id == null ) {
			throw new RentalDetailsNotFoundExcep(ID_NOT_NULL);
		}
		
		if( !this.existsById(id) ) {
			throw new RentalDetailsNotFoundExcep(VALUE_EMPTY);
		}
		rentalRepo.deleteById(id);	
	}

	@Override
	public boolean existsById(Integer id) throws RentalDetailsNotFoundExcep {
		if(id == null) {
			throw new RentalDetailsNotFoundExcep(RENTALDETAILS_NOT_NULL);
		}
		return rentalRepo.existsById(id);
	}

}
