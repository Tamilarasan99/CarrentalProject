package com.rental.carrental.exception;

public class CustomerNullExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public CustomerNullExcep() {
		this.text = "Car Not Found";
		
	}
	public CustomerNullExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}