package com.rental.carrental.exception;

public class RentalDetailsNotFoundExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public RentalDetailsNotFoundExcep() {
		this.text = "RentalDetails Not Found";
		
	}
	public RentalDetailsNotFoundExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}