package com.rental.carrental.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rental.carrental.exception.UserNotFoundExcep;
import com.rental.carrental.exception.UserNullExcep;

import com.rental.carrental.model.RentalDetails;
import com.rental.carrental.service.RentalDetailsService;

@RestController
@RequestMapping(path = "/json/rentaldetails", produces = "application/json")
public class RentalDetailsRestController {

	@Autowired
	private RentalDetailsService rentalDetailService;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Object> getRentalDetailById(@PathVariable Integer id) {
		RentalDetails rentalDetails = null;

		try {
			rentalDetails = rentalDetailService.findById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(rentalDetails);
	}
	
	
	@GetMapping("/getall")
	public ResponseEntity<Object> getAllRentalDetail() {
		List<RentalDetails> rentalDetailsList = null;
		try {
			rentalDetailsList = rentalDetailService.findAll();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		return ResponseEntity.ok(rentalDetailsList);
	}
	
	@PostMapping("/post")
	public ResponseEntity<Object> postRentalDetail(@RequestBody RentalDetails rentalDetails) {
		try {
			if (!rentalDetailService.existsById(rentalDetails.getRentalId())) {
				rentalDetails = rentalDetailService.save(rentalDetails);
			} else {
				return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(rentalDetails);
			}
		} catch (UserNullExcep | UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.CREATED).body(rentalDetails);
	}
	
	@PutMapping("/put")
	public ResponseEntity<Object> putRentalDetail(@RequestBody RentalDetails rentalDetails) {
		try {
			if (rentalDetailService.existsById(rentalDetails.getRentalId())) {
				rentalDetails = rentalDetailService.save(rentalDetails);
			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(rentalDetails);
			}
		} catch (UserNullExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(rentalDetails);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteRentalDetailById(@PathVariable Integer id) {
		try {
			rentalDetailService.deleteById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("delete success");
	}

	@GetMapping("/exists/{id}")
	public ResponseEntity<Object> RentalDetailExistsById(@PathVariable Integer id) {
		boolean exists = false;
		try {
			exists = rentalDetailService.existsById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(exists);
	}
	
}
