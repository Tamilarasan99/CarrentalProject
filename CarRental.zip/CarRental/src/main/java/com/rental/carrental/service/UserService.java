package com.rental.carrental.service;

import java.util.List;



import com.rental.carrental.exception.UserNotFoundExcep;
import com.rental.carrental.exception.UserNullExcep;
import com.rental.carrental.model.User;

public interface UserService {

	public User findById(Integer id) throws UserNotFoundExcep;
	
	public List<User> findAll();
	
	public User save(User user) throws UserNullExcep;
	
	public void deleteById(Integer id) throws UserNotFoundExcep;
	
	public boolean existsById(Integer id) throws UserNotFoundExcep;
	
	public long count() ;
}
