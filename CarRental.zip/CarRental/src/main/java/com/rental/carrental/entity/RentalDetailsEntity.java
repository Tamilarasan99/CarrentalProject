package com.rental.carrental.entity;


import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.rental.carrental.enumeration.Status;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Component
@Scope("prototype")
@Entity

public class RentalDetailsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int rentalId;
	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "car_id")
	private CarEntity rentalCar;
	
	@Column(name = "start_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date startDate;
	
	@Column(name = "end_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;
	
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn
	private CustomerEntity rentalCustomer;
	
	
	@Enumerated(EnumType.STRING)
	@Column
	private Status status;
	
	public RentalDetailsEntity() {
		super();
	}
	public RentalDetailsEntity(int rentalId, CarEntity rentalCar, Date startDate, Date endDate,
			CustomerEntity rentalCustomer, Status status) {
		super();
		this.rentalId = rentalId;
		this.rentalCar = rentalCar;
		this.startDate = startDate;
		this.endDate = endDate;
		this.rentalCustomer = rentalCustomer;
		this.status = status;
	}
	public int getRentalId() {
		return rentalId;
	}
	public void setRentalId(int rentalId) {
		this.rentalId = rentalId;
	}
	public CarEntity getRentalCar() {
		return rentalCar;
	}
	public void setRentalCar(CarEntity rentalCar) {
		this.rentalCar = rentalCar;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public CustomerEntity getRentalCustomer() {
		return rentalCustomer;
	}
	public void setRentalCustomer(CustomerEntity rentalCustomer) {
		this.rentalCustomer = rentalCustomer;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RentalDetailsEntity [rentalId=" + rentalId + ", rentalCar=" + rentalCar + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", rentalCustomer=" + rentalCustomer + ", status=" + status + "]";
	}
	
}
