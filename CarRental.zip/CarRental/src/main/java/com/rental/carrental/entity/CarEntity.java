package com.rental.carrental.entity;

import java.util.Arrays;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component
@Scope("prototype")
@Entity

public class CarEntity {

	@Id
	private String carNo;
	private String carModel;
	private int seatcount;
	private double rentPerday;
	private byte[] carImage;
	public CarEntity() {
		super();
	}
	public CarEntity(String carModel, String carNo, int seatcount, double rentPerday, byte[] carImage) {
		super();
		this.carModel = carModel;
		this.carNo = carNo;
		this.seatcount = seatcount;
		this.rentPerday = rentPerday;
		this.carImage = carImage;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getCarNo() {
		return carNo;
	}
	public void setCarNo(String carNo) {
		this.carNo = carNo;
	}
	public int getSeatcount() {
		return seatcount;
	}
	public void setSeatcount(int seatcount) {
		this.seatcount = seatcount;
	}
	public double getRentPerday() {
		return rentPerday;
	}
	public void setRentPerday(double rentPerday) {
		this.rentPerday = rentPerday;
	}
	public byte[] getCarImage() {
		return carImage;
	}
	public void setCarImage(byte[] carImage) {
		this.carImage = carImage;
	}
	@Override
	public String toString() {
		return "CarEntity [carModel=" + carModel + ", carNo=" + carNo + ", seatcount=" + seatcount + ", rentPerday="
				+ rentPerday + ", carImage=" + Arrays.toString(carImage) + "]";
	}
	
}
