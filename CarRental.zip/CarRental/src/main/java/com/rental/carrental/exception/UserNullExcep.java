package com.rental.carrental.exception;

public class UserNullExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public UserNullExcep() {
		this.text = "Null";
		
	}
	public UserNullExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}
