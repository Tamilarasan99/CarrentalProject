package com.rental.carrental.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.rental.carrental.enumeration.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
@Component
@Scope("prototype")
@Entity

@Inheritance(strategy = InheritanceType.JOINED)
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="id")
    protected int userId;
    
    @Column(name = "password")
    protected String userPassword;
    
    @Enumerated(EnumType.STRING)
    protected Role role;
	
	public UserEntity() {
		super();
	}
	public UserEntity( String userPassword, Role role) {
		super();
		
		this.userPassword = userPassword;
		this.role = role;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", userPassword=" + userPassword + ", role=" + role + "]";
	}
	
	
}
