package com.rental.carrental.model;


import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.rental.carrental.enumeration.Status;
@Component
@Scope("prototype")

public class RentalDetails {

	private int rentalId;
	private Car rentalCar;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date startDate;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;
	private Customer rentalCustomer;
	private Status status;
	public RentalDetails() {
		super();
	}
	public RentalDetails(int rentalId, Car rentalCar, Date startDate, Date endDate,
			Customer rentalCustomer, Status status) {
		super();
		this.rentalId = rentalId;
		this.rentalCar = rentalCar;
		this.startDate = startDate;
		this.endDate = endDate;
		this.rentalCustomer = rentalCustomer;
		this.status = status;
	}
	public int getRentalId() {
		return rentalId;
	}
	public void setRentalId(int rentalId) {
		this.rentalId = rentalId;
	}
	public Car getRentalCar() {
		return rentalCar;
	}
	public void setRentalCar(Car rentalCar) {
		this.rentalCar = rentalCar;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate2) {
		this.startDate = startDate2;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Customer getRentalCustomer() {
		return rentalCustomer;
	}
	public void setRentalCustomer(Customer rentalCustomer) {
		this.rentalCustomer = rentalCustomer;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RentalDetails [rentalId=" + rentalId + ", rentalCar=" + rentalCar + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", rentalCustomer=" + rentalCustomer + "]";
	}
	
	
}
