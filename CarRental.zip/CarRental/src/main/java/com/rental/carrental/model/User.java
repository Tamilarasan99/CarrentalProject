package com.rental.carrental.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.rental.carrental.enumeration.Role;
@Component
@Scope("prototype")
public class User {

	protected int userId;
	protected String userPassword;
	protected Role role;
	public User() {
		super();
	}
	public User( String userPassword, Role role) {
		super();
		
		this.userPassword = userPassword;
		this.role = role;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userPassword=" + userPassword + "]";
	}
	
	
}
