package com.rental.carrental.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import com.rental.carrental.exception.UserNotFoundExcep;
import com.rental.carrental.exception.UserNullExcep;
import com.rental.carrental.model.User;
import com.rental.carrental.service.UserService;

@RestController
@RequestMapping(path = "/json/user", produces = "application/json")
public class UserRestController {

	@Autowired
	private JdbcUserDetailsManager jdbcUserDetailsManager;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private UserService userService;
	
	public void createSecurityUser(User user) {
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(user.getRole().toString()));
		String encodededPassword = passwordEncoder.encode(user.getUserPassword());
		org.springframework.security.core.userdetails.User userSec = new org.springframework.security.core.userdetails.User(""+user.getUserId(), encodededPassword, authorities) ;
		jdbcUserDetailsManager.createUser(userSec);
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Object> getUserById(@PathVariable Integer id) {
		User user = null;

		try {
			user = userService.findById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(user);
	}
	
	
	@GetMapping("/getall")
	public ResponseEntity<Object> getAllUser() {
		List<User> userList = null;
		try {
			userList = userService.findAll();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		return ResponseEntity.ok(userList);
	}
	
	@PostMapping("/post")
	public ResponseEntity<Object> postUser(@RequestBody User user) {
		try {
			if (!userService.existsById(user.getUserId())) {
				user = userService.save(user);
			} else {
				return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(user);
			}
		} catch (UserNullExcep | UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.CREATED).body(user);
	}
	
	@PutMapping("/put")
	public ResponseEntity<Object> putUser(@RequestBody User user) {
		try {
			if (userService.existsById(user.getUserId())) {
				user = userService.save(user);
			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(user);
			}
		} catch (UserNullExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(user);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteUserById(@PathVariable Integer id) {
		try {
			userService.deleteById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("delete success");
	}

	@GetMapping("/exists/{id}")
	public ResponseEntity<Object> userExistsById(@PathVariable Integer id) {
		boolean exists = false;
		try {
			exists = userService.existsById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(exists);
	}
	
	@GetMapping("/count")
	public ResponseEntity<Object> userCount() {
		long count = 0;
		try {
			count = userService.count();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(count);
	}
	
}
