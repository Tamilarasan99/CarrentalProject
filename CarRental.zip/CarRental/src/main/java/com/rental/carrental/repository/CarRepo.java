package com.rental.carrental.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.rental.carrental.entity.CarEntity;

public interface CarRepo extends JpaRepository<CarEntity, String> {

	
	@Query("SELECT c FROM CarEntity c WHERE NOT EXISTS "
			+ "(SELECT rd FROM RentalDetailsEntity rd WHERE rd.rentalCar = c "
			+ "AND ((:startDate BETWEEN rd.startDate AND rd.endDate) "
			+ "OR (:endDate BETWEEN rd.startDate AND rd.endDate) "
			+ "OR (rd.startDate BETWEEN :startDate AND :endDate)))")
	public List<CarEntity> findAvailableCarsBwtweenDates(@Param("startDate") Date startDate,
			                                 @Param("endDate") Date endDate);
}
