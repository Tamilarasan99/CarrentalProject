package com.rental.carrental.exception;

public class CarNullExcep extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String text;
	public CarNullExcep() {
		this.text = "Car Not Found";
		
	}
	public CarNullExcep(String text) {
		super();
		this.text = text;
	}
	@Override
	public String toString() {
		return  text;
	}
	
	
}
