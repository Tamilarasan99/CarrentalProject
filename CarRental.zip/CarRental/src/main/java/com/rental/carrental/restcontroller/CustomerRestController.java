package com.rental.carrental.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rental.carrental.exception.UserNotFoundExcep;
import com.rental.carrental.exception.UserNullExcep;
import com.rental.carrental.model.Customer;

import com.rental.carrental.service.CustomerService;

@RestController
@RequestMapping(path = "/json/customer", produces = "application/json")
public class CustomerRestController {

	@Autowired
	private CustomerService custService;
	
	@Autowired
	private UserRestController userRest;
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Object> getCustomerById(@PathVariable Integer id) {
		Customer customer = null;

		try {
			customer = custService.findById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(customer);
	}
	
	
	@GetMapping("/getall")
	public ResponseEntity<Object> getAllCustomer() {
		List<Customer> custList = null;
		try {
			custList = custService.findAll();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		return ResponseEntity.ok(custList);
	}
	
	@PostMapping("/post")
	public ResponseEntity<Object> postCustomer(@RequestBody Customer customer) {
		try {
			if (!custService.existsById(customer.getUserId())) {
				customer = custService.save(customer);
			} else {
				return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(customer);
			}
		} catch (UserNullExcep | UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		userRest.createSecurityUser(customer);
		return ResponseEntity.status(HttpStatus.CREATED).body(customer);
	}
	
	
	
	
	@PutMapping("/put")
	public ResponseEntity<Object> putCustomer(@RequestBody Customer customer) {
		try {
			if (custService.existsById(customer.getUserId())) {
				customer = custService.save(customer);
			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(customer);
			}
		} catch (UserNullExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(customer);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteCustomerById(@PathVariable Integer id) {
		try {
			custService.deleteById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("delete success");
	}

	@GetMapping("/exists/{id}")
	public ResponseEntity<Object> CustomerExistsById(@PathVariable Integer id) {
		boolean exists = false;
		try {
			exists = custService.existsById(id);
		} catch (UserNotFoundExcep e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.ok(exists);
	}
	
}
