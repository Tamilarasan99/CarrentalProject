package com.java.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.DTO.UsersDTO;
import com.mysql.cj.Session;
@WebServlet(urlPatterns = "/checkout")
public class CheckoutServlet  extends HttpServlet{
public void service(HttpServletRequest request,HttpServletResponse response) {
	String door=request.getParameter("door");
	String street=request.getParameter("street");
	String area=request.getParameter("area");
	String district=request.getParameter("district");
	String state=request.getParameter("state");
	String zip=request.getParameter("zip");
	String payment=request.getParameter("payment");

	
	HttpSession ses=request.getSession();
	UsersDTO user=(UsersDTO)ses.getAttribute("userdata");
	System.out.println("user:"+user.getFullname());
	
	System.out.println(door+","+street+","+area+","+district+","+state+","+zip+","+payment);


}

}
