package com.java.service;

import java.util.ArrayList;

import com.java.DAO.CartDAO;
import com.java.DAO.DAO;
import com.java.DAO.DAOFactory;
import com.java.DTO.CartDTO;

public class CartServiceImpl implements CartService {

	@Override
	public int AddToCart(CartDTO cartdto) {
//		System.out.println("cartserviceimpl");
//		System.out.println("inside cartservice:"+cartdto);
		CartDAO dao=DAOFactory.getCartDAO();
		int id=dao.getNextUserid();
		System.out.println("id:"+id);
		cartdto.setId(id);
//		System.out.println("after adding id in cartservice:"+cartdto);		
		int x=dao.AddToCart(cartdto);
		
		
		return x;
	}

	@Override
	public ArrayList<CartDTO> getAllCartItemsbyUserID(int userid) {
		// TODO Auto-generated method stub
		CartDAO dao=DAOFactory.getCartDAO();
		ArrayList<CartDTO> items=dao.getAllCartItemsbyUserID(userid);
//				CartDTO cartdto=null;
//				double totalprice=0;
//				for(CartDTO item:items) {
//					cartdto=new CartDTO();
//					cartdto.setId(item.getId());
//
//					cartdto.setBookid(item.getBookid());
//					cartdto.setUserid(item.getUserid());
//					cartdto.setPrice(item.getPrice());
//					cartdto.setBookName(item.getBookName());
//					
//					totalprice+=item.getTotalprice();
//					System.out.println("toatal:"+totalprice);
//					System.out.println("cartdto:"+cartdto);
//					
//					cartdto.setTotalprice(totalprice);
//					
//				}
//				System.out.println(cartdto.getTotalprice());
//				System.out.println("cartdto3:"+cartdto);

		
		return items;
	}

	@Override
	public void deleteItem(int itemid, int userid) {
	CartDAO	dao=DAOFactory.getCartDAO();
	dao.deleteItem(itemid, userid);
	}

	
}
